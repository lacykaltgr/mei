# Most Exciting Input
Generate ***Most Exciting Input*** to explore and understand Tensorflow/PyTorch model's behavior by identifying input samples that induce high activation from specific neurons in your model.
